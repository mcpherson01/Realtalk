jQuery(document).ready(function($){
	$(window).load(function(){
	"use strict";

	});
});
