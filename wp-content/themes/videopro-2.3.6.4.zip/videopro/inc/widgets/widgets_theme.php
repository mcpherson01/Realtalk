<?php
require_once get_template_directory() . '/inc/widgets/popular_posts.php';

require_once get_template_directory() . '/inc/widgets/widget-recent-comment.php';

require_once get_template_directory() . '/inc/widgets/widget-social-accounts.php';

require_once get_template_directory() . '/inc/widgets/widget-categories.php';

