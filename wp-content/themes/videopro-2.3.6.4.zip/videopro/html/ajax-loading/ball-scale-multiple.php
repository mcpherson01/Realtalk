<?php
/*
*
* ball-scale-multiple
*
*/
?>
<div class="loader-inner ball-scale-multiple">
	<div></div>
	<div></div>
	<div></div>
</div>