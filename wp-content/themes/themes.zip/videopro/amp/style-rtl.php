<style>
    body {
        direction: rtl;
    }
    .amp-wp-title {
        text-align: right;
    }
    .amp-wp-article-header {
        /*flex-direction: row-reverse;*/
    }
    .amp-wp-article-header .amp-wp-meta:first-of-type {
        text-align: right;
    }
    .amp-wp-article-header .amp-wp-meta:last-of-type {
        text-align: left;
    }
    .post_amp_content {
        text-align: right;
    }
    .clearfix:after {
        content: "";
        display: table;
        clear: both;
    }
    .toolbar-right .next-video {
        float: left;
    }
    .toolbar-right .prev-video {
        float: right;
    }
    .related-posts {
        text-align: right;
    }
    ul.related-posts li {
        list-style-type: none;
    }
    .amp-wp-article-footer {
        text-align: right;
    }
    .amp-wp-footer {
        text-align: right;
    }
    .amp-wp-footer p {
        margin: 0;
    }
    .back-to-top {
        right: auto;
        left: 0;
    }
</style>