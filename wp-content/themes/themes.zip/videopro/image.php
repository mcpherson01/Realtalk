<?php

wp_redirect(get_permalink($post->post_parent));