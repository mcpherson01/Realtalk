<?php
/*
*
* ball-scale
*
*/
?>
<div class="loader-inner ball-scale">
	<div></div>
</div>