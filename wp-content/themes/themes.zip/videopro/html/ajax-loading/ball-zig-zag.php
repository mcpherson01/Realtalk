<?php
/*
*
* ball-zig-zag
*
*/
?>
<div class="loader-inner ball-zig-zag">
	<div></div>
	<div></div>
</div>