<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package cactus
 */
?>
<?php dynamic_sidebar( 'headline-sidebar' );?>
