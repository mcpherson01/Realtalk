<div>
    {{ _wpcc("Please click the following link to confirm your feature request") }}: @if(isset($url) && $url) <a href="{!! $url !!}">{!! $url !!}</a> @endif
</div>