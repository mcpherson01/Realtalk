<tr data-id="section-{{ str_slug($title) }}" @if(isset($class) && $class) class="{{ $class }}" @endif>
    <td colspan="2">
        <h4 class="section-title">{!! $title !!}</h4>
    </td>
</tr>