<tr class="section-title-container">
    <td colspan="2">
        <div class="section-title">
            {{ $title }}
        </div>
    </td>
</tr>