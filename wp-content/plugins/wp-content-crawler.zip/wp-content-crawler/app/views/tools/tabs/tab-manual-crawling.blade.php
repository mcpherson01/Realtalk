{{-- MANUAL CRAWLING TOOL --}}
@include('tools.tools.tool-manually-crawl')

{{-- CRAWLING RESULTS --}}
@include('tools.partials.component-urls')