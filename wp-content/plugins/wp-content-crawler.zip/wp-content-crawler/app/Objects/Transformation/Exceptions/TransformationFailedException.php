<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 16/02/2019
 * Time: 19:00
 *
 * @since 1.9.0
 */

namespace WPCCrawler\Objects\Transformation\Exceptions;


use Exception;

class TransformationFailedException extends Exception {

}