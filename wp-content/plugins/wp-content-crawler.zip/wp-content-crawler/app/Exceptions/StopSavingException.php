<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 18/11/2018
 * Time: 07:13
 */

namespace WPCCrawler\Exceptions;


use Exception;

class StopSavingException extends Exception {

}