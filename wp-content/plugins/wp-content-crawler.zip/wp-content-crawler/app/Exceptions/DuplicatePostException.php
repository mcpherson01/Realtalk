<?php
/**
 * Created by PhpStorm.
 * User: turgutsaricam
 * Date: 05/12/2018
 * Time: 19:45
 *
 * @since 1.8.0
 */

namespace WPCCrawler\Exceptions;


use Exception;

class DuplicatePostException extends Exception {

}