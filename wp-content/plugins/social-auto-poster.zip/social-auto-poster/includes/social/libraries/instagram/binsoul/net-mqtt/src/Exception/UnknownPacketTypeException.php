<?php

namespace BinSoul\Net\Mqtt\Exception;

/**
 * Will be thrown if a packet type is unknown.
 */
class UnknownPacketTypeException extends \Exception
{
}
