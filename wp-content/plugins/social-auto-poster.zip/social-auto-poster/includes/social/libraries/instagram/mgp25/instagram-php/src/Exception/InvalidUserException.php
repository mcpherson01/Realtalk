<?php

namespace InstagramAPI\Exception;

class InvalidUserException extends RequestException
{
}
