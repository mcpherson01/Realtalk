/* Elfsight (c) elfsight.com */

(function($) {
	$(function() {
		$(document).foundation();
		hljs.initHighlightingOnLoad();
	});
})(jQuery);